# day 30 today we going to design a button with an awesome hover effect.

A Pen created on CodePen.io. Original URL: [https://codepen.io/atechajay/pen/WNZpLMQ](https://codepen.io/atechajay/pen/WNZpLMQ).

